<nav class="layout-footer footer bg-footer-theme">
    <div class="container-fluid d-flex flex-wrap justify-content-center justify-content-sm-between align-items-center container-p-x pb-3">
      <div class="pt-3">
        Copyright © <?php echo e(now()->format('Y')); ?> <span class="footer-text font-weight-bolder">Pusat Pembinaan, Pendidikan dan Pelatihan BPPT<span>
      </div>
      <div class="pt-3">
        <span class="footer-text d-flex">Powered By <a href="https://www.4visionmedia.com" target="_blank" title="Perusahaan Jasa Pembuatan Website, Aplikasi, Digital Marketing, Design Company Profile, Software" style="display: inline-block; width: 100px; margin-left: 10px;"><img src="<?php echo e(asset('assets/tmplts_backend/images/logo-4vm.svg')); ?>"></a></span>
      </div>
      <!-- <div>
        
      </div> -->
    </div>
</nav>
<?php /**PATH C:\laragon\www\e-learning-bppt\resources\views/layouts/backend/includes/layout-footer.blade.php ENDPATH**/ ?>