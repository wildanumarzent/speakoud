<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/tmplts_backend/vendor/libs/bootstrap-select/bootstrap-select.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <h6 class="card-header">
      Form User
    </h6>
    <form action="<?php echo e(!isset($data['user']) ? route('user.store') : route('user.update', ['id' => $data['user']->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if(isset($data['user'])): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>
      <div class="card-body">
        <div class="form-group row">
            <div class="col-md-2 text-md-right">
              <label class="col-form-label text-sm-right">Nama</label>
            </div>
            <div class="col-md-10">
              <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e((isset($data['user'])) ? old('name', $data['user']->name) : old('name')); ?>" placeholder="masukan nama..." autofocus>
              <?php echo $__env->make('components.field-error', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-2 text-md-right">
              <label class="col-form-label text-sm-right">Email</label>
            </div>
            <div class="col-md-10">
              <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e((isset($data['user'])) ? old('email', $data['user']->email) : old('email')); ?>" placeholder="masukan email...">
              <?php echo $__env->make('components.field-error', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-2 text-md-right">
              <label class="col-form-label text-sm-right">Username</label>
            </div>
            <div class="col-md-10">
              <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e((isset($data['user'])) ? old('username', $data['user']->username) : old('username')); ?>" placeholder="masukan username...">
              <?php echo $__env->make('components.field-error', ['field' => 'username'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php if(isset($data['user'])): ?>
          <?php if($data['user']->roles[0]->name == 'developer' || $data['user']->roles[0]->name == 'administrator'): ?>
          <div class="form-group row">
              <div class="col-md-2 text-md-right">
                <label class="col-form-label text-sm-right">Roles</label>
              </div>
              <div class="col-md-10">
                <select class="selectpicker show-tick <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="roles" data-style="btn-default">
                    <option value="" disabled selected>Pilih</option>
                    <?php $__currentLoopData = $data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->name); ?>" <?php echo e(isset($data['user']) ? old('roles', $data['user']->roles[0]->name) == $item->name ? 'selected' : '' : old('roles') == $item->name ? 'selected' : ''); ?>>
                          <?php echo e(strtoupper($item->name)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <label class="error jquery-validation-error small form-text invalid-feedback" style="display: inline-block;color:red;"><?php echo $message; ?></label>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div>
          <?php else: ?>
          <input type="hidden" name="roles" value="<?php echo e((isset($data['user'])) ? old('roles', $data['user']->roles[0]->name) : old('roles')); ?>">
          <?php endif; ?>
        <?php else: ?>
          <div class="form-group row">
            <div class="col-md-2 text-md-right">
              <label class="col-form-label text-sm-right">Roles</label>
            </div>
            <div class="col-md-10">
              <select class="selectpicker show-tick <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="roles" data-style="btn-default">
                  <option value="" disabled selected>Pilih</option>
                  <?php $__currentLoopData = $data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->name); ?>" <?php echo e(isset($data['user']) ? old('roles', $data['user']->roles[0]->name) == $item->name ? 'selected' : '' : old('roles') == $item->name ? 'selected' : ''); ?>>
                        <?php echo e(strtoupper($item->name)); ?>

                      </option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <label class="error jquery-validation-error small form-text invalid-feedback" style="display: inline-block; color:red;"><?php echo $message; ?></label>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
        <?php endif; ?>
        <div class="form-group row">
          <div class="col-md-2 text-md-right">
            <label class="col-form-label text-sm-right">Password</label>
          </div>
          <div class="col-md-10">
            <div class="input-group">
            <input type="password" id="password-field" class="form-control gen-field <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" value="<?php echo e(old('password')); ?>" placeholder="masukan password...">
            <div class="input-group-append">
              <span toggle="#password-field" class="input-group-text toggle-password fas fa-eye"></span>
              <span class="btn btn-outline-warning ml-2" id="generate">Generate</span>
            </div>
            <?php echo $__env->make('components.field-error', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>
        </div>
        <div class="form-group row">
          <div class="col-md-2 text-md-right">
            <label class="col-form-label">Konfirmasi Password</label>
          </div>
          <div class="col-md-10">
            <div class="input-group">
            <input type="password" id="password-confirm-field" class="form-control gen-field <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" placeholder="masukan konfirmasi password...">
            <div class="input-group-append">
              <span toggle="#password-confirm-field" class="input-group-text toggle-password-confirm fas fa-eye"></span>
            </div>
            <?php echo $__env->make('components.field-error', ['field' => 'password_confirmation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
          </div>
        </div>
      </div>
      <div class="card-footer">
        <div class="row">
          <div class="col-md-10 ml-sm-auto text-md-left text-right">
            <a href="<?php echo e(route('user.index')); ?>" class="btn btn-danger" title="klik untuk kembali ke list" data-toggle="tooltip">Kembali</a>
            <button type="submit" class="btn btn-primary" name="action" value="save" title="klik untuk menyimpan" data-toggle="tooltip"><?php echo e(isset($data['user']) ? 'Simpan perubahan' : 'Simpan'); ?></button>
          </div>
        </div>
      </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/tmplts_backend/vendor/libs/bootstrap-select/bootstrap-select.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsbody'); ?>
<script>
//show & hide password
$(".toggle-password, .toggle-password-confirm").click(function() {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
});
//generate password
function makeid(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }

    return result;
}
$("#generate").click(function(){
    $(".gen-field").val(makeid(8));
});
</script>

<?php echo $__env->make('components.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-learning-bppt\resources\views/backend/user_management/users/form.blade.php ENDPATH**/ ?>