<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/tmplts_backend/vendor/libs/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/tmplts_backend/vendor/css/pages/account.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/tmplts_backend/fancybox/fancybox.min.css')); ?>">
<script src="<?php echo e(asset('assets/tmplts_backend/wysiwyg/tinymce.min.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/tmplts_backend/vendor/libs/sweetalert2/sweetalert2.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header with-elements">
        <h5 class="card-header-title mt-1 mb-0"><i class="las la-edit"></i> Edit profile</h5>
    </div>
    <form action="<?php echo e(route('profile.edit')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="card-body">
            <div class="bg-white ui-bordered mb-2">
                <a href="#general" class="d-flex justify-content-between text-body py-3 px-4 collapsed" data-toggle="collapse" aria-expanded="true">
                    <strong>General</strong>
                    <span class="collapse-icon"></span>
                </a>
                <div id="general" class="text-muted collapse show">
                    <div class="card-body pb-2">
                        <div class="form-group">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name', $data['user']->name)); ?>" placeholder="Enter name...">
                            <?php echo $__env->make('components.field-error', ['field' => 'name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="hidden" name="old_email" value="<?php echo e($data['user']->email); ?>">
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email', $data['user']->email)); ?>" placeholder="Enter email...">
                            <?php echo $__env->make('components.field-error', ['field' => 'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username', $data['user']->username)); ?>"
                                placeholder="Enter username...">
                            <?php echo $__env->make('components.field-error', ['field' => 'username'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="col-form-label">Current password (<em>if you change password</em>)</label>
                            <div class="input-group">
                                <input type="password" id="current-password-field" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="current_password"
                                    value="<?php echo e(old('current_password')); ?>"
                                    placeholder="Enter current password...">
                                <div class="input-group-append">
                                    <span toggle="#current-password-field" class="input-group-text toggle-current-password fas fa-eye" title="Click to show password"></span>
                                </div>
                                <?php echo $__env->make('components.field-error', ['field' => 'current_password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">New password</label>
                                    <div class="input-group">
                                        <input type="password" id="password-field" class="form-control gen-field <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                            placeholder="Enter new password...">
                                        <div class="input-group-append">
                                            <span toggle="#password-field" class="input-group-text toggle-password fas fa-eye"></span>
                                        </div>
                                        <?php echo $__env->make('components.field-error', ['field' => 'password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Repeat new password</label>
                                    <div class="input-group">
                                        <input type="password" id="password-confirm-field" class="form-control gen-field <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="password_confirmation" placeholder="Enter repeat new password...">
                                        <div class="input-group-append">
                                            <span toggle="#password-confirm-field" class="input-group-text toggle-password-confirm fas fa-eye"></span>
                                        </div>
                                        <?php echo $__env->make('components.field-error', ['field' => 'password_confirmation'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group ml-2">
                                <span class="btn btn-warning"  id="generate"><i class="las la-qrcode"></i> Generate password</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">City / Town</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city"
                                value="<?php echo e(old('city', ($data['information'] != null ? $data['information']->general['city'] : ''))); ?>" placeholder="Enter city/town...">
                            <?php echo $__env->make('components.field-error', ['field' => 'city'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Description</label>
                            <textarea class="form-control mb-1 tiny <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" placeholder="Enter description...">
                                <?php echo e(old('description', ($data['information'] != null ? $data['information']->general['description'] : ''))); ?>

                            </textarea>
                            <?php echo $__env->make('components.field-error', ['field' => 'description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white ui-bordered mb-2">
                <a href="#user-picture" class="d-flex justify-content-between text-body py-3 px-4 collapsed" data-toggle="collapse" aria-expanded="true">
                    <strong>User Picture</strong>
                    <span class="collapse-icon"></span>
                </a>
                <div id="user-picture" class="text-muted collapse show">
                    <div class="card-body pb-2">
                        <div class="form-group media" style="min-height:1px">
                            <div class="ui-bg-cover" style="width: 100px;height: 100px;background-image: url('<?php echo e($data['user']->getPhoto($data['user']->photo['file'])); ?>');"></div>
                            <div class="media-body ml-3">
                                <label class="form-label">
                                    Change picture :
                                </label><br>
                                <small class="text-muted">Allowed : <strong><?php echo e(strtoupper(config('addon.mimes.photo.m'))); ?></strong></small>
                                <label class="custom-file mt-3">
                                    <label class="custom-file-label mt-1" for="file-1"></label>
                                    <input type="hidden" name="old_photo" value="<?php echo e($data['user']->photo['file']); ?>">
                                    <input class="form-control custom-file-input file <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="file-1" lang="en" name="file">
                                    <?php echo $__env->make('components.field-error', ['field' => 'file'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Picture description</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['photo_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="photo_description" value="<?php echo e(old('photo_description', $data['user']->photo['description'])); ?>" placeholder="Enter description...">
                            <?php echo $__env->make('components.field-error', ['field' => 'photo_description'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white ui-bordered mb-2">
                <a href="#additional-name" class="d-flex justify-content-between text-body py-3 px-4 collapsed" data-toggle="collapse" aria-expanded="true">
                    <strong>Additional name</strong>
                    <span class="collapse-icon"></span>
                </a>
                <div id="additional-name" class="text-muted collapse">
                    <div class="card-body pb-2">
                        <div class="form-group">
                            <label class="form-label">First name - phonetic</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="first_name"
                                value="<?php echo e(old('first_name', ($data['information'] != null ? $data['information']->additional_name['first_name'] : ''))); ?>" placeholder="Enter first name...">
                            <?php echo $__env->make('components.field-error', ['field' => 'first_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Surname - phonetic</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['sur_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="sur_name"
                                value="<?php echo e(old('sur_name', ($data['information'] != null ? $data['information']->additional_name['sur_name'] : ''))); ?>" placeholder="Enter sur name...">
                            <?php echo $__env->make('components.field-error', ['field' => 'sur_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Middle name</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="middle_name"
                                value="<?php echo e(old('middle_name', ($data['information'] != null ? $data['information']->additional_name['middle_name'] : ''))); ?>" placeholder="Enter middle name...">
                            <?php echo $__env->make('components.field-error', ['field' => 'middle_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Alternate name</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['alternate_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alternate_name"
                                value="<?php echo e(old('alternate_name', ($data['information'] != null ? $data['information']->additional_name['alternate_name'] : ''))); ?>" placeholder="Enter alternate name...">
                            <?php echo $__env->make('components.field-error', ['field' => 'alternate_name'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-white ui-bordered mb-2">
                <a href="#optional" class="d-flex justify-content-between text-body py-3 px-4 collapsed" data-toggle="collapse" aria-expanded="true">
                    <strong>Optional</strong>
                    <span class="collapse-icon"></span>
                </a>
                <div id="optional" class="text-muted collapse">
                    <div class="card-body pb-2">
                        <div class="form-group">
                            <label class="form-label">Web page</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['web_page'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="web_page"
                                value="<?php echo e(old('web_page', ($data['information'] != null ? $data['information']->optional['web_page'] : ''))); ?>" placeholder="Enter web page...">
                            <?php echo $__env->make('components.field-error', ['field' => 'web_page'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">ICQ number</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['icq_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="icq_number"
                                value="<?php echo e(old('icq_number', ($data['information'] != null ? $data['information']->optional['icq_number'] : ''))); ?>" placeholder="Enter icq number...">
                            <?php echo $__env->make('components.field-error', ['field' => 'icq_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Skype ID</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['skype_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="skype_id"
                                value="<?php echo e(old('skype_id', ($data['information'] != null ? $data['information']->optional['skype_id'] : ''))); ?>" placeholder="Enter skype id...">
                            <?php echo $__env->make('components.field-error', ['field' => 'skype_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">AIM ID</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['aim_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="aim_id"
                                value="<?php echo e(old('aim_id', ($data['information'] != null ? $data['information']->optional['aim_id'] : ''))); ?>" placeholder="Enter aim id...">
                            <?php echo $__env->make('components.field-error', ['field' => 'aim_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Yahoo ID</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['yahoo_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="yahoo_id"
                                value="<?php echo e(old('yahoo_id', ($data['information'] != null ? $data['information']->optional['yahoo_id'] : ''))); ?>" placeholder="Enter yahoo id...">
                            <?php echo $__env->make('components.field-error', ['field' => 'yahoo_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">MSN ID</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['msn_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="msn_id"
                                value="<?php echo e(old('msn_id', ($data['information'] != null ? $data['information']->optional['msn_id'] : ''))); ?>" placeholder="Enter msn id...">
                            <?php echo $__env->make('components.field-error', ['field' => 'msn_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">ID number</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="id_number"
                                value="<?php echo e(old('id_number', ($data['information'] != null ? $data['information']->optional['id_number'] : ''))); ?>" placeholder="Enter id number...">
                            <?php echo $__env->make('components.field-error', ['field' => 'id_number'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Institution</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['institution'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="institution"
                                value="<?php echo e(old('institution', ($data['information'] != null ? $data['information']->optional['institution'] : ''))); ?>" placeholder="Enter institution...">
                            <?php echo $__env->make('components.field-error', ['field' => 'institution'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Departemnt</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['departement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="departement"
                                value="<?php echo e(old('departement', ($data['information'] != null ? $data['information']->optional['departement'] : ''))); ?>" placeholder="Enter departement...">
                            <?php echo $__env->make('components.field-error', ['field' => 'departement'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                                value="<?php echo e(old('phone', ($data['information'] != null ? $data['information']->optional['phone'] : ''))); ?>" placeholder="Enter phone...">
                            <?php echo $__env->make('components.field-error', ['field' => 'phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Mobile phone</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['mobile_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mobile_phone"
                                value="<?php echo e(old('mobile_phone', ($data['information'] != null ? $data['information']->optional['mobile_phone'] : ''))); ?>" placeholder="Enter mobile phone...">
                            <?php echo $__env->make('components.field-error', ['field' => 'mobile_phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Address</label>
                            <input type="text" class="form-control mb-1 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address"
                                value="<?php echo e(old('address', ($data['information'] != null ? $data['information']->optional['address'] : ''))); ?>" placeholder="Enter address...">
                            <?php echo $__env->make('components.field-error', ['field' => 'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer d-flex justify-content-center">
            <button type="submit" class="btn btn-primary">Save changes</button>&nbsp;&nbsp;
            <a href="" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/tmplts_backend/vendor/libs/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>"></script>
<script src="<?php echo e(asset('assets/tmplts_backend/fancybox/fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/tmplts_backend/vendor/libs/sweetalert2/sweetalert2.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsbody'); ?>
<script src="<?php echo e(asset('assets/tmplts_backend/js/pages_account-settings.js')); ?>"></script>

<script>
$(".toggle-password-current, .toggle-password, .toggle-password-confirm").click(function() {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
});

function makeid(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }

    return result;
}

$("#generate").click(function(){
    $(".gen-field").val(makeid(8));
});
</script>

<?php echo $__env->make('includes.tiny-mce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-learning-bppt\resources\views/backend/user_management/profile-form.blade.php ENDPATH**/ ?>