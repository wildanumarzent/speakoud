<?php if(isset($breadcrumbsBackend)): ?>
<h4 class="font-weight-light py-3 mb-2">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">
            <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </li>
        <?php $__currentLoopData = $breadcrumbsBackend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item">
            <a href="<?php echo e($val); ?>"><?php echo e($key); ?></a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</h4>
<?php endif; ?>
<?php /**PATH C:\laragon\www\e-learning-bppt\resources\views/components/breadcrumbs.blade.php ENDPATH**/ ?>