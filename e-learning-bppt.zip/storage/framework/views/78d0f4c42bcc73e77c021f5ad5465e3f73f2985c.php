<?php $__env->startSection('content'); ?>
<h4 class="font-weight-bold py-3 mb-3">
    Dashboard
    <div class="text-muted text-tiny mt-1"><small class="font-weight-normal">Today is <?php echo e(now()->format('l, j F Y (H:i A)')); ?></small></div>
</h4>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsbody'); ?>
<?php echo $__env->make('components.toastr', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\e-learning-bppt\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>