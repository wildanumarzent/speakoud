<?php if($errors->has($field)): ?>
<small class="invalid-feedback"><?php echo $errors->first($field); ?></small>
<?php endif; ?>
<?php /**PATH C:\laragon\www\e-learning-bppt\resources\views/components/field-error.blade.php ENDPATH**/ ?>