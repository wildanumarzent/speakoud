<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProgramBahanPelatihanLinkTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('program_bahan_pelatihan_link', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('program_pelatihan_id');
            $table->unsignedBigInteger('program_mata_pelatihan_id');
            $table->unsignedBigInteger('program_materi_pelatihan_id');
            $table->unsignedBigInteger('program_bahan_pelatihan_id');
            $table->unsignedBigInteger('creator_id');
            $table->text('meeting_link');
            $table->timestamps();

            $table->foreign('program_pelatihan_id')->references('id')
                ->on('program_pelatihan')
                ->cascadeOnDelete();
            $table->foreign('program_mata_pelatihan_id')->references('id')
                ->on('program_mata_pelatihan')
                ->cascadeOnDelete();
            $table->foreign('program_materi_pelatihan_id')->references('id')
                ->on('program_materi_pelatihan')
                ->cascadeOnDelete();
            $table->foreign('program_bahan_pelatihan_id')->references('id')
                ->on('program_bahan_pelatihan')
                ->cascadeOnDelete();
            $table->foreign('creator_id')->references('id')->on('users')
                ->cascadeOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('program_bahan_pelatihan_link');
    }
}
