<?php

return [
    'photo' => [
        'm' => 'jpg,jpeg,png,svg',
        'p' => '500x500 px'
    ],
];
